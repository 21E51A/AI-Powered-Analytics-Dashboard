'use client';

import { DateRange, RangeKeyDict } from 'react-date-range';
import 'react-date-range/dist/styles.css';
import 'react-date-range/dist/theme/default.css';
import { useState } from 'react';
import { Range } from 'react-date-range';

export default function DateFilter({
  onChange,
}: {
  onChange: (range: Range) => void;
}) {
  const [range, setRange] = useState<Range[]>([
    {
      startDate: new Date(),
      endDate: new Date(),
      key: 'selection',
    },
  ]);

  return (
    <DateRange
      editableDateInputs={true}
      onChange={(item: RangeKeyDict) => {
        setRange([item.selection]);
        onChange(item.selection);
      }}
      moveRangeOnFirstSelection={false}
      ranges={range}
    />
  );
}
