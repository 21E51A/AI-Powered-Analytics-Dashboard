(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_0326c8fa._.js",
  "static/chunks/node_modules_jspdf_dist_jspdf_es_min_c277e70f.js",
  "static/chunks/node_modules_recharts_es6_33262975._.js",
  "static/chunks/node_modules_80fcae69._.js",
  "static/chunks/src_app_page_tsx_b025fed5._.js"
],
    source: "dynamic"
});
